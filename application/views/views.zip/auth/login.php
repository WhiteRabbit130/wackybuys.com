  <div class="login-box">

      <div class="login-logo">
        <a href="<?php echo site_url();?>"><b>Creative</b>designs</a>
      </div><!-- /.login-logo -->

          <div class="login-box-body">
            <p class="login-box-msg">Sign in to start your session</p>

            <div id="infoMessage" class="text-danger"><?php echo $message;?></div>

            <?php echo form_open("auth/login");?>

              <div class="form-group has-feedback">
                <?php echo form_input($identity);?>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
              </div>
              <div class="form-group has-feedback">
                <?php echo form_input($password);?>
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
              </div>
              <label>
                <input type="checkbox" id="showPassword"> Show Password
              </label>
              <div class="g-recaptcha" data-sitekey="6LeNblspAAAAAAjE_Itbl4DkXIibaeuaWW7QMhvT"></div>

              <div class="row" style="padding-left: 20px; padding-top: 10px;">

                <div class="col-xs-8" style="padding: left 10px;">    
                  <div class="checkbox icheck">
                    <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?>  <?php echo lang('login_remember_label', 'remember');?>
                  </div>                        
                </div><!-- /.col -->

                <div class="col-xs-4">
                  <?php $data = array('type'  =>'submit',
                                      'class' =>'btn btn-primary btn-block btn-flat',
                                  'content'   => "<i class='glyphicon glyphicon-log-in'></i> ".lang('login_submit_btn'))?>
                   
                  <?php echo form_button($data);?>
                </div><!-- /.col -->

              </div><!-- /.row -->

            <?php echo form_close();?>

            <a href="forgot_password"><?php echo lang('login_forgot_password');?></a><br>
            <a href="<?php echo site_url('auth/create_user');?>" class="text-center">Register a new membership</a>

          </div><!-- /.login-box-body -->

  </div><!-- /.login-box -->
   
</body>
<!-- load recaptcha.js -->
<script src="https://www.google.com/recaptcha/api.js"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
$(document).ready(function() {
  $('#showPassword').on('change', function() {
    var pass = $('#password');
    if($(this).is(':checked')) {
      pass.attr('type', 'text');
    }else{
      pass.attr('type', 'password');

    }

  });
});
</script>