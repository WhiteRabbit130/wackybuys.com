<?php echo form_open("auth/verifyCode");?>
    <label for="verifyCode">VerifyCode:</label>
    <input type="text" name="verifyCode">
    <input type="email" value="<?=$email?>" name = "email">
    <div class="col-xs-4">
      <?php $data = array('type'  =>'submit',
                          'class' =>'btn btn-primary btn-block btn-flat',
                      'content'   => "<i class='glyphicon glyphicon-log-in'></i> "."Verify")?>
        
      <?php echo form_button($data);?>
    </div>
<?php echo form_close();?>